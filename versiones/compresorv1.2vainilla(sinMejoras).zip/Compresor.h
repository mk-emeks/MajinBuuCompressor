
#ifndef COMPRESOR_H_
#define COMPRESOR_H_

#include <iostream>
#include <stdio.h>
#include "Declaracion_de_constantes.h"
#include "Nombre_archivo.h"
#include "blockSorting.h"
#include "blockSortingLeft.h"
#include "mtf.h"
#include "Aritmetico.h"
#include "Writer.h"

class Compresor{

	private:

		LInt t_bloque;

		UChar* bloque_caracteres;

	public:

		// Deberia comprimir el archivo que se pide, creando un archivo: nombre_archivo.1
		void comprimir(char* nombre_archivo);

		// pre: se le debe pasar un archivo .1
		void descomprimir(char* nombre_archivo_con_extencion);

		bool not_end_of_file(FILE* &fd);

		//void reservar_espacio_para_overhead ();



};



#endif