
#ifndef DECLARACION_DE_CONSTANTES_H_
#define DECLARACION_DE_CONSTANTES_H_

#include <iostream>
#include <string>
#include <stdio.h>

using namespace std;

/** Definicion de tipos: Mientras los demas ficheros incluyan a funciones generales entenderan le redefinicion **/ 
typedef unsigned char UChar;
typedef unsigned long int LInt;
const LInt MEMORIA_POR_ACCESO = 1000000;

//depracated ?:
// sirve para mostrar el array dinamico de caracteres por consola

/*void mostrar_bloque_caracteres (UChar* bloque_caracteres, LInt &t_bloque) 
{
	cout << "( - B L O Q U E  N U E V O - )"<< endl;
	for (int i = 0 ; i < t_bloque ; i++ ) {
	cout << (int)bloque_caracteres[i]<<"-";
	};
	cout << endl;
}*/

#endif		