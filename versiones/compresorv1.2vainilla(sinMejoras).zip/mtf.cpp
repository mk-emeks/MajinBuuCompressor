
#include "mtf.h"

using namespace std;

const short unsigned int max_carateres = 256;

UChar* moveToFront(UChar* tira_localizada, LInt	long_tira)
{
	//Armamos la "tira ordenada de 0 a 255"
	UChar* tira_ordenada = new UChar[max_carateres];
    ordenar_tira(tira_ordenada);

	// muestro de la tira ordenada
	/*for (int i = 0 ; i < max_carateres ; i++) 
	{
		cout << (int)tira_ordenada[i] << '-';
	}*/

	// Mtf:

	UChar* tiraMtf = tira_localizada;

	LInt cant_chars = 0 ;

    for (LInt i = 0 ; i < long_tira ; i++) {
        
        bool igual = false;
        LInt j = -1;

        // j antes de llegar a 255 deberia activar la bandera
        while(!igual)
        {
            if ( tira_localizada[i] == tira_ordenada[j + 1] )
            {
            	igual = true;
            }
            j++;
        }
           
        tiraMtf[i] = (UChar)j; // guardando posicion en tira de salida

        //Swap de lista ordenada MTF : se hace de atras para adelante!

        UChar aux_swap;
        for( LInt k = j ; k > 0 ; k--)
        {
            aux_swap = tira_ordenada[k];
            tira_ordenada[k] = tira_ordenada[k-1];
            tira_ordenada[k-1] = aux_swap;
        }
            
    }       

    return tiraMtf;


}

UChar* vueltaMoveToFront(UChar* tiraMTF, LInt long_tira) {

    //Armamos la "tira ordenada de 0 a 255"
    UChar* tira_ordenada = new UChar[max_carateres];
    UChar* tira_localizada = new UChar[long_tira];

    ordenar_tira(tira_ordenada);

    for (LInt i = 0 ; i < long_tira ; i++) {
        
        tira_localizada[i] = (UChar)tira_ordenada[(int)tiraMTF[i]];

        //Swap de lista ordenada MTF : se hace de atras para adelante!

        UChar aux_swap;
        for( int k = (int)tiraMTF[i] ; k > 0 ; k--)
        {
            aux_swap = tira_ordenada[k];
            tira_ordenada[k] = tira_ordenada[k-1];
            tira_ordenada[k-1] = aux_swap;
        }
            
    }       

    return tira_localizada;
}


void ordenar_tira(UChar* tira_ordenada) {
    
    // modo comun:
    /*for ( LInt i = 0 ; i < max_carateres ; i++ ) 
    {
        tira_ordenada[i] = (UChar)i;
    }*/

    // modo hardcore:
    LInt j = 0;

    // minusculas
    for ( LInt i = 97 ; i <= 122 ; i++ ) 
    {
        tira_ordenada[j] = (UChar)i;
        j++;
    }

    // mayusculas
    for ( LInt i = 65 ; i <= 90 ; i++ ) 
    {
        tira_ordenada[j] = (UChar)i;
        j++;
    }

    // simbolos y numeros
    for ( LInt i = 32 ; i <= 64 ; i++ ) 
    {
        tira_ordenada[j] = (UChar)i;
        j++;
    }

    for ( LInt i = 91 ; i <= 96 ; i++ ) 
    {
        tira_ordenada[j] = (UChar)i;
        j++;
    }

    // cosas raras 1
    for ( LInt i = 0 ; i <= 31 ; i++ ) 
    {
        tira_ordenada[j] = (UChar)i;
        j++;
    }

    // cosas raras 2
    for ( LInt i = 123 ; i <= 255 ; i++ ) 
    {
        tira_ordenada[j] = (UChar)i;
        j++;
    }

}