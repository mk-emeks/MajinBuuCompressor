
#ifndef __NIVEL_H__
#define __NIVEL_H__

#include <iostream>
#include <stdio.h>
#include <math.h>


// Te permite pedirle valores de un rango mayor, al igual que enviar de parametro un unsigned short int.
typedef unsigned short int Valor;

// propios del manejo interno de la clase nivel
typedef unsigned char Valor_nivel; // el labura de 0 a 255 max caracteres
typedef unsigned char N_valor_nivel; // el labura de 0 a 255 max "posiciones"

typedef unsigned long int Probabilidad;
typedef unsigned long int intAritmetico; // soy conceptualmente un forro, cambiar a long long!!!!

const unsigned short int eof = 256; // (!) no me deja declarar la constante

class Nivel {

	private:

		N_valor_nivel cantidad_caracteres_por_nivel; 
		intAritmetico frecuencia_total; // cantidad de valores observados hasta el momento

		// los "vectores" son asociativos!
		Valor_nivel* valores; // lista de valores
		Probabilidad* frecuencia_caracteres; // lista con la cantidad de veces que se vio cada valor 

		bool ultimo_nivel; // sirve para indicar si es ultimo nivel -> en ese caso, el esc no debe ser contemplado.

		// METODOS PRIVADOS:

		/** compresion **/
		void inicializar_valores(intAritmetico& piso_relativo, intAritmetico& techo_relativo, intAritmetico& frecuencia_nivel);

		N_valor_nivel buscar_caracter(Valor valor_procesado);

		void calcular_valores_caracter_compresion(intAritmetico& piso_relativo, intAritmetico& techo_relativo, intAritmetico& frecuencia_nivel, bool& hubo_caracter_especial, Valor valor_procesado , N_valor_nivel& posicion_encontrada);
		/** **/


		/** descompresion **/

		// va buscando en que intervalo el techo es mayor que la frecuencia acumulada
		void generar_valores_descompresion_entre_intervalos_de_caracteres(intAritmetico& acumulador,intAritmetico& piso_relativo, intAritmetico& techo_relativo, intAritmetico frecuenciaAcumulada, bool& hubo_caracter_especia, unsigned short int& posicion_caracter);	

		/** **/

		// neutro (lo usan los dos)
		// se la pasa la posicion donde se encuentra el caracter procesado y la aumenta, tmb aumenta la frecuencia total.
		void actualizar_frecuencia_caracteres(N_valor_nivel posicion_encontrada);



	public:


		Nivel (Valor_nivel* valores_requeridos , N_valor_nivel cantidad_valores , bool es_ultimo_nivel);

		~Nivel();

		bool es_ultimo_nivel();
	
		void generar_valores_intervalo_compresion(intAritmetico& piso_relativo, intAritmetico& techo_relativo, intAritmetico& frecuencia_nivel, bool& hubo_caracter_especial, Valor valor_procesado);

		/** descompresion **/
		intAritmetico get_frecuencia_nivel(); 

		void generar_valores_intervalo_descompresion(intAritmetico& piso_relativo, intAritmetico& techo_relativo, intAritmetico frecuenciaAcumulada, bool& hubo_escape, unsigned short int& posicion_caracter);

		// este metodo supone que lo que se pide esta dentro de los limites del nivel, sino picha como el mejor.
		// ya que devolvera cosas apuntadas en memoria invalidas (peor caso, sean parecidas a o lo que uno espera)
		// es unsigned short int, simplemente para poder soportar el eof.
		Valor get_valor(unsigned short int posicion);
		/** **/


		// con busquedad binaria, se hara un swap -> sirve para la implementacion de multi modelos.
		//cambiar_valor(Valor valor_a_cambiar, Valor valor_a_cambiar);


};



#endif
