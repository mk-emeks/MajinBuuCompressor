
#ifndef __NOMBRE_ARCHIVO_H__
#define __NOMBRE_ARCHIVO__

#include <iostream>
#include <stdio.h>
#include <string>

using namespace std;

// OBS: A veces anda mal, sobre todo cuando descomprime, fijar el cast_to_ptrchar

class Nombre_archivo {

	private:

		char* c_nombre; // lo usa para devolver el cast

		string s_nombre;


		void liberar_memoria() {
			// no tiene problema si la memoria no se pidio!
			delete [] c_nombre;
			//cout << "libere memoria de c_nombre" << endl;
		}

	public:

		// (!) ojo que en cada nuevo cast, o cuando muera el objeto, te va a limpiar la memoria de donde apunta
		//	el char* que te devuelve.
		char* cast_to_ptrchar() {

			liberar_memoria();
			c_nombre = new char[s_nombre.size()];

			for (int i= 0 ; i < s_nombre.size() ; i++) {
				c_nombre[i] = s_nombre[i];
			}

			return c_nombre;

		}

		~Nombre_archivo() {
	
			liberar_memoria();	
		}

		Nombre_archivo(string s) {
			
			this->s_nombre = s;
		}

		Nombre_archivo(char* s) {
			
			this->s_nombre = s;
		}


		// anda como quiere!! rarisimoooo
		void cambiar_nombre(string s_nombre) {

			//cout << "cambio de nombre:" << endl;
			//cout << "antes: " << get_nombre_archivo() << endl;
			this->s_nombre=s_nombre;
			//cout << "despues: " << get_nombre_archivo() << endl;
		}

		void append(string agregado_al_final) {

			s_nombre = s_nombre + agregado_al_final;
		}

		// De existir en el nombre del archivo, borra el substring del final,
		// obviamente si coincide con lo que le pedis.
		bool borrar_extencion(string extencion_al_final) {
		
			bool esta = false;

			unsigned short int j = (extencion_al_final.size()-1);
			unsigned short int machs = 0;

			for (int i = s_nombre.size()-1  ; i >= (s_nombre.size()-extencion_al_final.size()) ; i--) {
				
				if (s_nombre[i] == extencion_al_final[j]) {
					machs++;
					//cout << s_nombre[i];
				}
				//cout << endl;
				j--;
				
			}

			if (machs == extencion_al_final.size()) {
				esta = true;
			}

			if (esta) {

				string nombre_recortado = s_nombre.substr( 0 , (s_nombre.size()-extencion_al_final.size()) ) ;
				//cout << nombre_recortado << endl;
				cambiar_nombre(nombre_recortado);

			}
			return esta;

		}

		string get_nombre_archivo() {
			return s_nombre;
		}

};


#endif