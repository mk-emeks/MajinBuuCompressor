
#ifndef MTF_H_
#define MTF_H_

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <string>
#include "Declaracion_de_constantes.h"

/* 
	Post: devuelve la el move to front de la tira localizada
*/

// CUANDO SE LIBERA LA MEMORIA DE LAS TIRAS?????????????????????????????????????????
UChar* moveToFront(UChar* tira_localizada, LInt	long_tira);

UChar* vueltaMoveToFront(UChar* tiraMTF, LInt long_tira);

// metodo privado
void ordenar_tira(UChar* tira_ordenada);
    
#endif