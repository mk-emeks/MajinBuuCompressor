
#include "Compresor.h"

using namespace std;

void Compresor::comprimir(char* nombre_archivo){

    // abrimos el archivo -> ojo si no existe pincha todo!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    FILE* fd = fopen(nombre_archivo, "rb"); //abrimos el archivo modo read

	this->t_bloque = MEMORIA_POR_ACCESO; 

	// calculos de tamanio de overhead
	fseek(fd,0,SEEK_END);
	LInt t_archivo = ftell(fd);

	unsigned short cantidad_de_bloques = (unsigned short)(t_archivo / this->t_bloque);
	if ( (t_archivo % this->t_bloque) > 0 ) {
		cantidad_de_bloques++;
	}

	// medido en bytes
	unsigned int espacio_reservado = 0;
	espacio_reservado = espacio_reservado + (unsigned int) (sizeof(unsigned short)); // espacio para guardar la cantidad de indices
	espacio_reservado = espacio_reservado + (unsigned int) (sizeof(LInt))*cantidad_de_bloques; // espacio para guardar todos los indices de los bloques

	cout << "cantidad bloques: " << cantidad_de_bloques << " espacio reservado: " << espacio_reservado << endl;

	fseek(fd,0,SEEK_SET); // volvemos al inicio en el archivo original

    // inicializamos el aritmetico
	Aritmetico* aritmetico = new Aritmetico();
	Nombre_archivo* nombre_archivo_con_extencion = new Nombre_archivo(nombre_archivo);
	nombre_archivo_con_extencion->append(".1");
	aritmetico->set_nombre_archivo_compresion(nombre_archivo_con_extencion->cast_to_ptrchar());

	delete nombre_archivo_con_extencion;

	// reservamos el espacio de overhead
	aritmetico->get_IO_processor()->reservar_espacio_para_overhead(espacio_reservado);

	cout << "cantidad de bloques: " << cantidad_de_bloques << endl;
	LInt* bloque_de_indices = new LInt [cantidad_de_bloques]; // inicializamos vector donde guardaremos los indices
	unsigned short iterador_bloques = 0;

	bool fin_compresion = false; // bandera para terminar compresion
	while (!fin_compresion)
	{

        this->bloque_caracteres = new UChar[this->t_bloque];
		
		// leemos de a bloques:	
        if (not_end_of_file(fd)) {

        	//fread devuelve la cantidad que leyo	
        	this->t_bloque = (fread(this->bloque_caracteres,sizeof(UChar),this->t_bloque,fd));
        	cout << "cantidad tomada por bloque: " << this->t_bloque << endl;

        	// lectura adelantada
        	if ( !(not_end_of_file(fd)) ) { // si es fin de archivo, debemos poner en true la bandera
				cout << "estoy en ultimo bloque" << endl;
				fin_compresion = true;
			}

        }
		
		cout << "Block Sorting:" << endl;

		// pedimos memoria again! (ojo) : con super eficiencia podrias pisar??
		UChar* resultadoParcial = new UChar[this->t_bloque];

		// tener comentada o una u otra (!)
		LInt indiceParcial = blockSortingLeft(resultadoParcial, this->bloque_caracteres, this->t_bloque);
		//LInt indiceParcial = blockSorting(resultadoParcial, this->bloque_caracteres, this->t_bloque);
		
		cout << "grabamos el indice: " << indiceParcial << endl;
		bloque_de_indices[iterador_bloques] = indiceParcial;
		iterador_bloques++;

		cout << "termino bloque del bs" << endl;

		cout << "Move to front:" << endl;

		
		resultadoParcial = moveToFront(resultadoParcial,this->t_bloque);

		// salida mtf
		
		/*for (LInt i = 0 ; i < this->t_bloque ; i++) {
			cout << (int)resultadoParcial[i]<<"-";
		}
		cout << endl;*/
		
		cout << "termino mtf" << endl;
		
		// comprimimos!
		for (int i = 0; i < this->t_bloque; i++) {
			aritmetico->comprimir_valor(resultadoParcial[i]);
		}
		
		if (fin_compresion) {
			aritmetico->comprimir_valor(eof); // Comprime EOF
			aritmetico->terminarCompresion();
		}

		// banderas
		cout << "cantidad bits comprimidos " << aritmetico->get_cantidad_bits_comprimidos() << endl;
		cout << "cantidad bytes comprimidos " << (aritmetico->get_cantidad_bits_comprimidos()/8) << endl;
		cout << "cantidad de breaks " << aritmetico->get_cantidad_de_breaks() << endl;
		cout << "cantidad de caracteres" << this->t_bloque << endl;

		/** LIBERAR MEMORIA **/
		delete [] this->bloque_caracteres;
		delete [] resultadoParcial; 

		//delete[] bloque_test; // descomentar si se usa test 0's!
	
	}

	unsigned short* cantidad_de_bloques_aux = new unsigned short;
	*cantidad_de_bloques_aux = cantidad_de_bloques;

	aritmetico->get_IO_processor()->escribir_en_overhead(cantidad_de_bloques_aux);
	aritmetico->get_IO_processor()->escribir_en_overhead(bloque_de_indices, cantidad_de_bloques);

	delete aritmetico, cantidad_de_bloques_aux;
	delete [] bloque_de_indices;

	/** CERRAR ARCHIVO **/
	fclose(fd); //siempre cerrarlo!

}


void Compresor::descomprimir(char* nombre_archivo_con_extencion){

	Writer* escritor = new Writer(); // encargado de generar la salida
	Aritmetico* aritmetico = new Aritmetico(); // encargado de la descompresion propiamente dicha
	Nombre_archivo* nombre_archivo = new Nombre_archivo(nombre_archivo_con_extencion);

	if (nombre_archivo->borrar_extencion(".1")) {

		// crear archivo para la descompression
		if (escritor->set_nombre_archivo_nuevo(nombre_archivo->cast_to_ptrchar())) {
			
			cout << "descomprimir y generar archivo salida" << endl; // ir descomprimiendo y guardando 
			
			// notar que se le pasa el archivo con extencio, ya que sobre el mismo queremos descomprimir!
			aritmetico->set_nombre_archivo_descompresion(nombre_archivo_con_extencion); 
			
			t_bloque = MEMORIA_POR_ACCESO;

			bool fin_descompresion = false;

			LInt* bloque_de_indices = new LInt[aritmetico->get_IO_processor()->get_cantidad_bloques()];

			aritmetico->get_IO_processor()->cargar_overhead(bloque_de_indices);



			LInt iterador_bloques = 0;

			aritmetico->empezar_descompresion(); // SOLO SE VIVE UNA VEZ

			//FUNCIONALIDAD LIMITADA A ARCHIVOS DE 1 SOLO BLOQUE
			while (!fin_descompresion) {

				this->bloque_caracteres = new UChar[this->t_bloque];

				LInt long_tira = 0;

				cout << "indice: " << bloque_de_indices[iterador_bloques] << endl;

				Valor caracterDescomprimido;

				while ( (long_tira < MEMORIA_POR_ACCESO) ) {
					
					// carga el caracter, si es el ultimo hay que cortar.
					caracterDescomprimido = aritmetico->descomprimir_valor();
						
					if (caracterDescomprimido == eof) {
						cout << "encontro EOF" << endl;
						fin_descompresion =true;
						break;
					}
					this->bloque_caracteres[long_tira] = (UChar)caracterDescomprimido;
					long_tira++;

				}

				cout << "longitud: "<< long_tira << endl;
				
				cout << "vuelta Move to front:" << endl;

				UChar* resultadoParcial = new UChar[long_tira];
				resultadoParcial = vueltaMoveToFront(this->bloque_caracteres, long_tira);

				cout << "vuelta Block Sorting:" << endl;

				this->bloque_caracteres = vueltaBlockSortingLeft(resultadoParcial,bloque_de_indices[iterador_bloques],long_tira);
				//this->bloque_caracteres = vueltaBlockSorting(resultadoParcial,bloque_de_indices[iterador_bloques],long_tira);
				iterador_bloques++;

				escritor->escribir(bloque_caracteres,long_tira);

				delete [] this->bloque_caracteres, resultadoParcial;
				
				//fin_descompresion = true;

			}

			escritor->cerrar_archivo();
			delete [] bloque_de_indices;

		} else{
			cout << "error al descomprimir: ya existe el archivo" << endl;
		}

	} else {
		cout << "error al descomprimir: el archivo que desea descomprimir, tiene una extención incorrecta o ni siquiera existe" << endl;
	}

	delete nombre_archivo, escritor, aritmetico;

}

// nada que ver jeje
bool Compresor::not_end_of_file(FILE* &fd) {
	if  ( feof(fd) ) {
		return false;
	} else {
		return true;
	}
}



	
	
		/** TESTs **/

		// test bloque 0's:
		/*
		UChar* bloque_test = new UChar[this->t_bloque];

		for ( int i = 0 ; i < this->t_bloque ; i++) {

			bloque_test[i] = 'a';

		}

		bloque_test = moveToFront(bloque_test,this->t_bloque);

		for (LInt i = 0 ; i < this->t_bloque ; i++) {
			cout << (int)bloque_test[i]<<"-";
		}
		cout << endl;

		for (int i = 0; i < this->t_bloque; i++) {
			aritmetico->comprimir_valor(bloque_test[i]);
		}
		if (this->t_bloque < MEMORIA_POR_ACCESO) {
			aritmetico->terminarCompresion();
		}
		*/

	
		// test a mano:
		/*aritmetico->comprimir_valor(38);
		aritmetico->comprimir_valor(12);
		aritmetico->comprimir_valor(0);
	
		aritmetico->terminarCompresion();
		*/