
#ifndef __WRITER_H__
#define __WRITER_H__

// Librerias
#include <iostream>
#include <stdio.h>
#include <string>
#include "Declaracion_de_constantes.h"

class Writer {

	private:

		FILE* fd;

		//bool hubo_error ();

	public:

		void cerrar_archivo();

		// devuelve true si pudo setiar el nombre. Sino false, es decir el archivo ya existe y no va querer pisarlo
		bool set_nombre_archivo_nuevo(char* nombre_archivo);

		// escribe un bloque de caracteres de cierto tamañano
		void escribir(UChar* bloque_caracteres, LInt &t_bloque); 
		
	
};


#endif