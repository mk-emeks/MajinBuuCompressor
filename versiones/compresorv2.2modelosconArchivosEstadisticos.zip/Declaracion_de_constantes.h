
#ifndef DECLARACION_DE_CONSTANTES_H_
#define DECLARACION_DE_CONSTANTES_H_

#include <iostream>
#include <string>
#include <stdio.h>



using namespace std;

/** Definicion de tipos: Mientras los demas ficheros incluyan a funciones generales entenderan le redefinicion **/ 
typedef unsigned char UChar;
typedef unsigned long int LInt;
const LInt MEMORIA_POR_ACCESO = 2000000;
const unsigned short TAMANIO_SUB_BLOQUE = 70;
const UChar OVERHEAD_MODELOS_POR_BYTE = 0x04; // el overhead del cambio de modelo, ocupa 2 bits por sub_bloque, por lo tanto entra 4 en un byte

// si solo hacemos inversio o no!
//const UChar OVERHEAD_MODELOS_POR_BYTE = 0x08; // el overhead del cambio de modelo, ocupa 1 bits por sub_bloque, por lo tanto entra 8 en un byte


// obs: los modelos se recorren distinto luego de un escape*
enum Modelos { Estructurado = 0, Invertido = 1 , Semi_invertido = 2 , Casi_Estructurado = 3 };

// quedo kirchnerista de milagro -> no me odien!

//depracated ?:
// sirve para mostrar el array dinamico de caracteres por consola

/*void mostrar_bloque_caracteres (UChar* bloque_caracteres, LInt &t_bloque) 
{
	cout << "( - B L O Q U E  N U E V O - )"<< endl;
	for (int i = 0 ; i < t_bloque ; i++ ) {
	cout << (int)bloque_caracteres[i]<<"-";
	};
	cout << endl;
}*/

#endif		