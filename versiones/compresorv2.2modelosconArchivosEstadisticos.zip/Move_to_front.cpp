
#include "Move_to_front.h"

using namespace std;

const short unsigned int max_carateres = 256;


// para estadisticas (provisorio)
// para mostrar salida mtf (provisorio)

Move_to_front::Move_to_front(){

        //abre el archivo para escritura,si no exite lo crea, si exite lo sobre escribe
        this->fd_archivo_frecuencia = fopen("frecuenciasCaracteresMft","w+");

        /** provisorio para guardar tira mtf en un archivo (!) **/
        this->fd_mtf = fopen("salidaMtf","w+");


        //abre el archivo para escritura, si no existe lo crea, si existe lo sobreescribe
        this->fd_promedio_nivel = fopen("PromedioPorNivel", "w+");


}

Move_to_front::~Move_to_front(){

        fclose(fd_archivo_frecuencia);
        fclose(fd_mtf);
        fclose(fd_promedio_nivel);

}
//

UChar* Move_to_front::moveToFront(UChar* tira_localizada, LInt	long_tira, Modelos* modelos_predominantes_aux)
{
	//Armamos la "tira ordenada de 0 a 255"
	UChar* tira_ordenada = new UChar[max_carateres];
    ordenar_tira(tira_ordenada);

    // Contadores de frecuencia de aparicion de caracteres numericos: (debe ser del mismo tipo que la constante TAMANIO_SUB_BLOQUE) 
    unsigned short* acumuladores = new unsigned short[max_carateres];
    unsigned short it_sub_bloques = 0;    

    // Inicializo en 0
    for (int i = 0; i < max_carateres; i++) {
        acumuladores[i] = 0;
    }

    // Mtf:
	UChar* tiraMtf = tira_localizada;
	LInt cant_chars = 0 ;

    //PROVISORIO ES PARA TENER EL TOTAL DE CADA NIVEL 
    LInt* total_para_promedio_por_nivel = new LInt[9];
    //inicializo el vector en cero
    for(int i=0; i<9; i++){
        total_para_promedio_por_nivel[i] = 0;
    }

    //

    LInt contador_de_bloques1 = 0; // provisorio!!!!!!

    int it_aux = 0; // FUNDAMENTAL!!!!!!!!!!!!!!!!!!!!!!!
    for (LInt i = 0 ; i < long_tira ; i++) {
        
        bool igual = false;
        LInt j = -1;

        // j antes de llegar a 255 deberia activar la bandera
        while(!igual)
        {
            if ( tira_localizada[i] == tira_ordenada[j + 1] )
            {
            	igual = true;
            }
            j++;
        }
           
        tiraMtf[i] = (UChar)j; // guardando posicion en tira de salida
        
        acumuladores[j]++; // Aumenta la cantidad de apariciones de j

        //cout<< "i: " << i<<" it_aux " << it_aux << endl;
        
        it_aux++;
        if ((it_aux == TAMANIO_SUB_BLOQUE || (i == long_tira-1) )) { 
            it_aux = 0;
            //cout << "entre" << endl;
            //Estadisticas: (provisorio)   
            stringstream strs_aux;
            strs_aux << endl << "Bloque Mtf: " << contador_de_bloques1 << endl << endl;
            string inicio = strs_aux.str();
            char* char_titulo = (char*) inicio.c_str();
            fputs(char_titulo, this->fd_archivo_frecuencia);

            contador_de_bloques1++;

            //PARA PODER VER TODOS LOS NIVELES
            for(int i=0; i<9 ; i++)
            {
                char* char_contador_nivel = calcular_acumulacion_por_nivel(i,acumuladores);
                fputs(char_contador_nivel, this->fd_archivo_frecuencia);
            }

            calcular_frecuencia_por_nivel(acumuladores,total_para_promedio_por_nivel);

            //ESTO ES LO QUE MUESTRA LAS FRECUENCIAS DE CADA CARACTER, SI QUERES VERLAS, TENES Q DESCOMENTAR ESTO, LO REEMPLAZE POR LO DE ARRIBA

            for (LInt t = 0 ; t < max_carateres ; t++) {

            // ESTADISTICAS: (provisorio)
            if (acumuladores[t] != 0){ 
        
                // salio de internet 
                stringstream strs;
                strs << (int)acumuladores[t] << endl;
                string temp_str = strs.str();
                char* char_type = (char*) temp_str.c_str();
                //

                stringstream strs_aux2;
                strs_aux2 << "el caracter: "<< t << " tiene frecuencia: ";
                string temporal2 = strs_aux2.str();
                char* char_aux = (char*) temporal2.c_str();


                 // ineficiente porque hace grabadas de a uno a disco pero bueno
                fputs( char_aux, this->fd_archivo_frecuencia);
                fputs( char_type ,this->fd_archivo_frecuencia);

                }
            }
            //

            // ELECCION MODELOS:

            modelos_predominantes_aux[it_sub_bloques] = Estructurado; // por default es el estructurado!

            // Casi_Estructurado("3") vs estructurado

            unsigned short contador_caracteres_modelos_Casi_Estructurado = 0;


            for ( int t = 2 ; t < 8  ; t++) { // nivel 2 + 3
                contador_caracteres_modelos_Casi_Estructurado += acumuladores[t];
            }


            if ( (contador_caracteres_modelos_Casi_Estructurado > acumuladores[1]) ) {
                modelos_predominantes_aux[it_sub_bloques] = Casi_Estructurado;
            }


            // Invertido_en_el_medio & Casi_invertido
            /*for ( int t = 16 ; t < 64 ; t++) { 
                contador_caracteres_modelos_Casi_Estructurado += acumuladores[t];
            }

            //unsigned short contadores_caracteres_0_y_1_aux = acumuladores [0] + acumuladores[1];

            if (contador_caracteres_modelos_Casi_Estructurado > acumuladores[0] ) {
                modelos_predominantes_aux[it_sub_bloques] = Casi_Estructurado;
            }*/


            // Semi_invertido("2") vs estructurado

            unsigned short contador_caracteres_modelos_Semi_invertido = 0;

            for ( int t = 2 ; t < 16 ; t++) { // del nivel 2 al 4to
                contador_caracteres_modelos_Semi_invertido += acumuladores[t];
            }

            unsigned short contadores_caracteres_0_y_1 = acumuladores [0] + acumuladores[1];

            if (contador_caracteres_modelos_Semi_invertido > contadores_caracteres_0_y_1/*acumuladores[0]*/ ) {
                modelos_predominantes_aux[it_sub_bloques] = Semi_invertido;
            }

            // invertidos("1") vs estructurado

            //if (modelos_predominantes_aux[it_sub_bloques] != Semi_invertido) {

            unsigned short contador_caracteres_modelo_invertido = 0; // debe ser del mismo tipo que la constante TAMANIO_SUB_BLOQUE   
            // a partir del caracter 64 se esta en el nivel 6 en adelante
            for (int t = 64 ; t < max_carateres ; t++) {
                contador_caracteres_modelo_invertido += acumuladores[t];
            }

            // si la suma total da mayor que la cantidad de 0's , se invierte el modelo
            if ( contador_caracteres_modelo_invertido > acumuladores[0]) { 
                modelos_predominantes_aux[it_sub_bloques] = Invertido;
            }
            //}
            //

            // reinicia los contadores
            for (int t = 0; t < max_carateres; t++) {
                acumuladores[t] = 0;
            }
            it_sub_bloques++;
        } 


        //Swap de lista ordenada MTF : se hace de atras para adelante!
        UChar aux_swap;
        for( LInt k = j ; k > 0 ; k--)
        {
            aux_swap = tira_ordenada[k];
            tira_ordenada[k] = tira_ordenada[k-1];
            tira_ordenada[k-1] = aux_swap;
        }

    }       

    // salida mtf
    /** provisorio para guardar tira mtf en un archivo (!) **/
    LInt contador_de_bloques2 = 0;
    LInt h = 0;
    it_aux = 0;
    for ( LInt w = 0; w < long_tira ; w++) {
        //cout << "w: "<<  w << endl;
        it_aux++;
        if ( ( it_aux == TAMANIO_SUB_BLOQUE)  || (w == long_tira-1) ) {
            it_aux = 0;  

            stringstream strs_aux;
            strs_aux << endl << "Bloque Mtf: "<< contador_de_bloques2 << endl;
            string temporal = strs_aux.str();
            char* char_aux = (char*) temporal.c_str();    
            fputs(char_aux,fd_mtf); 

            while ( h <= w ) { // H tmb queda crecida!!!!!!!!!!!!!!!!!!!!!!!!!!!
                //cout << "h:" << h << endl;
                // salio de internet 
                stringstream strs;
                strs << (int)tiraMtf[h];
                string temp_str = strs.str();
                char* char_type = (char*) temp_str.c_str();
                //

                // ineficiente porque hace grabadas de a uno a disco pero bueno!
                fputs( char_type ,fd_mtf);
                fputs("-",fd_mtf);     

                h++;
            }
            contador_de_bloques2++;
        }         
    }
    // 

    //PROVISORIO GRABA EN EL ARCHIVO EL PROMEDIO DE CADA NIVEL
    
    for(int i=0; i<9 ; i++){ 
    
    stringstream valor_por_nivel;
    valor_por_nivel << "El Nivel: " << i << " tiene un promedio de: " << (float)total_para_promedio_por_nivel[i]/it_sub_bloques << endl;  
    string valor_aux = valor_por_nivel.str();
    char* valor_aux2 = (char*) valor_aux.c_str();
    fputs(valor_aux2,this->fd_promedio_nivel);

    }

    //


    delete [] acumuladores;
    return tiraMtf;

}

UChar* Move_to_front::vueltaMoveToFront(UChar* tiraMTF, LInt long_tira) {

    //Armamos la "tira ordenada de 0 a 255"
    UChar* tira_ordenada = new UChar[max_carateres];
    UChar* tira_localizada = new UChar[long_tira];

    ordenar_tira(tira_ordenada);

    for (LInt i = 0 ; i < long_tira ; i++) {
        
        tira_localizada[i] = (UChar)tira_ordenada[(int)tiraMTF[i]];

        //Swap de lista ordenada MTF : se hace de atras para adelante!

        UChar aux_swap;
        for( int k = (int)tiraMTF[i] ; k > 0 ; k--)
        {
            aux_swap = tira_ordenada[k];
            tira_ordenada[k] = tira_ordenada[k-1];
            tira_ordenada[k-1] = aux_swap;
        }
            
    }       

    return tira_localizada;
}


void Move_to_front::ordenar_tira(UChar* tira_ordenada) {
    
    // modo comun:
    /*for ( LInt i = 0 ; i < max_carateres ; i++ ) 
    {
        tira_ordenada[i] = (UChar)i;
    }*/

    // modo hardcore:
    LInt j = 0;

    // minusculas
    for ( LInt i = 97 ; i <= 122 ; i++ ) 
    {
        tira_ordenada[j] = (UChar)i;
        j++;
    }

    // mayusculas
    for ( LInt i = 65 ; i <= 90 ; i++ ) 
    {
        tira_ordenada[j] = (UChar)i;
        j++;
    }

    // simbolos y numeros
    for ( LInt i = 32 ; i <= 64 ; i++ ) 
    {
        tira_ordenada[j] = (UChar)i;
        j++;
    }

    for ( LInt i = 91 ; i <= 96 ; i++ ) 
    {
        tira_ordenada[j] = (UChar)i;
        j++;
    }

    // cosas raras 1
    for ( LInt i = 0 ; i <= 31 ; i++ ) 
    {
        tira_ordenada[j] = (UChar)i;
        j++;
    }

    // cosas raras 2
    for ( LInt i = 123 ; i <= 255 ; i++ ) 
    {
        tira_ordenada[j] = (UChar)i;
        j++;
    }

}

char* Move_to_front::calcular_acumulacion_por_nivel(int nivel, unsigned short* acumuladores)
{
    int cantidad_caracteres;
    int nivel_inicio;
    //esto es una villereada pero es una villereada comoda
    switch(nivel)
    {
        case 2:
            cantidad_caracteres = 2;
            break;

        case 3:
            cantidad_caracteres = 4;
            break;

        case 4:
            cantidad_caracteres = 8;
            break;

        case 5:
            cantidad_caracteres = 16;
            break;

        case 6:
            cantidad_caracteres = 32;
            break;

        case 7:
            cantidad_caracteres = 64;
            break;

        case 8:
            cantidad_caracteres = 128;
            break;

        case 0:
            cantidad_caracteres = 1;
            break;
    
        case 1:
            cantidad_caracteres = 1;
            break;
    }   

    int acumulador_nivel = 0;

    if (nivel == 0)
    {

        acumulador_nivel = acumuladores[0];

    }else{  
        if (nivel == 1){

            acumulador_nivel = acumuladores[1];
        
        }else{

            for (int i=cantidad_caracteres; i < 2*cantidad_caracteres ; i++)
            {
                acumulador_nivel = acumulador_nivel + acumuladores[i];
            }
        } 
    }

    //emite el char* al archivo para el puts
    stringstream texto_nivel;
    texto_nivel << "el nivel: " << nivel << " tiene una frecuencia: " << acumulador_nivel << endl;
    string texto_final = texto_nivel.str();
    char* salida_al_archivo = (char*) texto_final.c_str();
    
    return salida_al_archivo;
}

void Move_to_front::calcular_frecuencia_por_nivel(unsigned short* acumuladores, LInt* promedioPorNivel)
{
    promedioPorNivel[0] += acumuladores[0];
    promedioPorNivel[1] += acumuladores[1];
 
    for (int i=2; i<4 ; i++){
        promedioPorNivel[2] += acumuladores[i];
    }
 
    for(int i=4; i<8 ; i++){
        promedioPorNivel[3] += acumuladores[i];
    }

   for(int i=8; i<16 ; i++){
        promedioPorNivel[4] += acumuladores[i];
    }

   for(int i=16; i<32 ; i++){
        promedioPorNivel[5] += acumuladores[i];
    }

   for(int i=32; i<64 ; i++){
        promedioPorNivel[6] += acumuladores[i];
    }   

   for(int i=64; i<128 ; i++){
        promedioPorNivel[7] += acumuladores[i];
    }
   
   for(int i=128; i<255 ; i++){
        promedioPorNivel[8] += acumuladores[i];
    } 

}