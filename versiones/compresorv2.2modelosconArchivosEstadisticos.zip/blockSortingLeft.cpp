
#include "blockSortingLeft.h"


using namespace std;

//Maximo para long int, que es lo que estamos usando, si cambiamos de tipo de dato hay que cambiar esto.
const LInt maximo = 4294967295;


LInt decrementarIndice(LInt aux, LInt &long_tira) {
    
    if (aux > 0) {
        return (aux-1);
    }
    else {
        if (aux == 0) {
            return (long_tira-1);
        }
    }
}

// sirve para ir llevando la posicion donde se encuentra el S del Block Sorting
void actualizarPosicionIndice(LInt &indice, LInt* vec, LInt n, LInt p, UChar* tira_texto, LInt &long_tira) {
    if (vec[n] == (long_tira-1)) {
        indice = n;         
        }
    if (vec[p] == (long_tira-1)) {
        indice = p;
    }
}

//Esta funcion evalua si vec[n] es mayor que vec[p] y devuelve TRUE en caso positivo y FALSE en caso negativo.
bool mayorQue(LInt* vec, LInt &n, LInt &p, UChar* tira_texto, LInt &long_tira) {
   
    if (tira_texto[vec[n]] > tira_texto[vec[p]]) {
        return true;
    }
    else {
        if (tira_texto[vec[n]] == tira_texto[vec[p]]) {
            LInt nAux = vec[n];
            LInt pAux = vec[p];
            LInt count = 0;

            while ((tira_texto[nAux] == tira_texto[pAux]) && (count <= long_tira)) {
                nAux = decrementarIndice(nAux, long_tira);
                pAux = decrementarIndice(pAux, long_tira);
                count++;
            }

            if (tira_texto[nAux] > tira_texto[pAux]) {
                return true;
            }
        }
    }
    return false;
}

LInt blockSortingLeft(UChar* salidaBs , UChar* tira_texto, LInt long_tira)
{
    LInt indice = 0 ;

    LInt vec[long_tira];

    //completando suffix array
    for (LInt i=0 ; i < long_tira ; i++) {

        vec[i] = i;
        //cout<< vec[i].posicion << " y " << vec[i].longitud << endl;

    }

    //ARMO EL MONTICULO
    for (LInt heapsize = 0; heapsize < long_tira; heapsize++) {

        LInt n = heapsize; //HIJO
        while (n > 0) {
            LInt p = floor((n-1)/2); //PADRE
            if (mayorQue(vec,n,p,tira_texto,long_tira)) {
                LInt aux = vec[n];
                vec[n] = vec[p];
                vec[p] = aux;
                actualizarPosicionIndice(indice,vec,n,p,tira_texto,long_tira);
                n = p;
            }
            else {
                break;
            }
        }
    }
    
    //ORDENO CON HEAPSORT
    LInt heapsize = long_tira;    
    while (heapsize > 0) {
        
        LInt aux = vec[0];
        vec[0] = vec[heapsize-1];
        vec[heapsize-1] = aux;
        actualizarPosicionIndice(indice,vec,0,heapsize-1,tira_texto,long_tira);
        heapsize--;

        LInt n = 0;
        while (true) {
            LInt left = (n*2)+1;
            if (left >= heapsize) {
                break;
            }
            LInt right = left+1;
            if (right >= heapsize) {
                if (mayorQue(vec,left,n,tira_texto,long_tira)) {
                    LInt aux = vec[left];
                    vec[left] = vec[n];
                    vec[n] = aux;
                    actualizarPosicionIndice(indice,vec,left,n,tira_texto,long_tira);    
                }
                break;    
            }
            if (mayorQue(vec,left,n,tira_texto,long_tira)) {
                if (mayorQue(vec,left,right,tira_texto,long_tira)) {
                    LInt aux = vec[left];
                    vec[left] = vec[n];
                    vec[n] = aux;
                    actualizarPosicionIndice(indice,vec,left,right,tira_texto,long_tira);
                    n = left;
                }
                else {
                    LInt aux = vec[n];
                    vec[n] = vec[right];
                    vec[right] = aux;
                    actualizarPosicionIndice(indice,vec,n,right,tira_texto,long_tira);
                    n = right;
                }
            }
            else {
                if (mayorQue(vec,right,n,tira_texto,long_tira)) {
                    LInt aux = vec[n];
                    vec[n] = vec[right];
                    vec[right] = aux;
                    actualizarPosicionIndice(indice,vec,n,right,tira_texto,long_tira);
                    n = right;
                }
                else {
                    break;
                }
            }
        }
    }

    // Preparamos la salida de block sorting: -> Conseguimos la ultima "columna":

    for ( int i = 0 ; i < long_tira ; i++) {

        if (vec[i] == long_tira-1) {
            salidaBs[i] = tira_texto[0];
        } 
        else {
            salidaBs[i] = tira_texto[vec[i]+1];  
        }
    }

    
    // muestra
    /*
    for ( int i = 0 ; i < long_tira ; i++ ) {

        mostrarBloqueCaracteres(vec[i].posicion,vec[i].longitud);
    }
    */

    return indice; //devolvemos el indice

}


UChar* vueltaBlockSortingLeft(UChar* salidaBS, LInt indice, LInt long_tira) {

    LInt i = indice;

    //Vectores que se crean para el funcionamiento del algoritmo. Estos se explican en el paper de Burrows-Wheeler, con los mismos nombres.
    LInt C[256];
    LInt P[long_tira];

    // Carga C (Instrucciones en el paper de Burrows-Wheeler)
    //Inicializo todos los datos de C en maximo, que es el maximo valor para nuestro tipo de dato.
    for (int h = 0; h < 256; h++) {
        C[h] = maximo;
    }

    //Para cada dato de la tira al que no se le calculo su valor en C, se le calcula. Si ya fue calculado, sigue adelante.
    //Optimizado para minimizar operaciones aritmeticas. Peor caso: 256*N
    for (LInt g = 0; g < long_tira; g++) {
        if (C[(int)salidaBS[g]] == maximo) {
            C[(int)salidaBS[g]] = 0;
            for (LInt t = 0; t < long_tira; t++) {
                if ((int)salidaBS[t] < (int)salidaBS[g]) {
                    C[(int)salidaBS[g]] = C[(int)salidaBS[g]] + 1;
                }
            } 
        }
    }

    // Carga P (Instrucciones en el paper de Burrows-Wheeler)
    //Optimizado para minimizar operaciones aritmeticas.
    LInt ultimaPos[256];
    for (int y = 0; y < 256; y++) {
        ultimaPos[y] = 0;
    }

    P[0] = 0;
    for (LInt t = 1; t < long_tira; t++) {
        
        P[t] = P[ultimaPos[(int)salidaBS[t]]];
        for (LInt h = ultimaPos[(int)salidaBS[t]]; h < t; h++) {
            if (salidaBS[h] == salidaBS[t]) {
                P[t] = P[t] + 1;
            }
        }
        ultimaPos[(int)salidaBS[t]] = t;
    }
    
    UChar* vueltaBS = new UChar[long_tira];
    
    //Arma la tira original de vuelta.
    for (LInt j = 0; j < long_tira; j++) {
        vueltaBS[j] = salidaBS[i];
        i = P[i] + C[(int)salidaBS[i]];    
    }
    
    //Devuelve la tira original.
    return vueltaBS;
}