
#ifndef MOVE_TO_FRONT_H_
#define MOVE_TO_FRONT_H_


#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include "Declaracion_de_constantes.h"

// para estadisticas (provisorio)
#include <sstream>
#include <string.h>

class Move_to_front{ 

private:

	FILE* fd_archivo_frecuencia; // para estadisticas (provisorio)
	FILE* fd_mtf; // para mostrar salida mtf (provisorio)
	FILE* fd_promedio_nivel;
	void ordenar_tira(UChar* tira_ordenada);

public:

	// se abre el archivo para grabar todas las frecuencias de un archivo a comprimir
	Move_to_front(); // para estadisticas (provisorio)

	~Move_to_front(); // para estadisticas (provisorio)

	/* 
	Post: devuelve el move to front de la tira localizada
	*/
	// CUANDO SE LIBERA LA MEMORIA DE LAS TIRAS?????????????????????????????????????????
	UChar* moveToFront(UChar* tira_localizada, LInt	long_tira, Modelos* caracteres_predominantes_aux);

	UChar* vueltaMoveToFront(UChar* tiraMTF, LInt long_tira);

	// absolutamente provisorio esto es para la lectura de las frecuencias
	char* calcular_acumulacion_por_nivel(int nivel, unsigned short* acumuladores);

	// absolutamente provisorio esto es para tener el promedio por nivel de todo los niveles
	void calcular_frecuencia_por_nivel(unsigned short* acumuladores,LInt* total_promedio_por_nivel);

}; 

#endif