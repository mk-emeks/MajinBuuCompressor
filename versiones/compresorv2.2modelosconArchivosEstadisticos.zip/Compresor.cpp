
#include "Compresor.h"

using namespace std;

Compresor::Compresor(){

	this->aritmetico = new Aritmetico();
	this->mtf = new Move_to_front();

	this->escritor = new Writer();

}

Compresor::~Compresor() {

	delete this->aritmetico, this->mtf, this->escritor;
}

void Compresor::comprimir(char* nombre_archivo){

    // abrimos el archivo -> ojo si no existe pincha todo!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    FILE* fd = fopen(nombre_archivo, "rb"); //abrimos el archivo modo read
	this->t_bloque = MEMORIA_POR_ACCESO; 

	// calculos de tamanio de overhead
	fseek(fd,0,SEEK_END);
	LInt t_archivo = ftell(fd);
	this->overhead = new Overhead(t_archivo);
	fseek(fd,0,SEEK_SET); // volvemos al inicio en el archivo original

	// asignamos extencion del archivo 
	Nombre_archivo* nombre_archivo_con_extencion = new Nombre_archivo(nombre_archivo);
	nombre_archivo_con_extencion->append(".1");

	//-> aca internamente se crea el IO_processor de la clase aritmetico
	this->aritmetico->set_nombre_archivo_compresion(nombre_archivo_con_extencion->cast_to_ptrchar()); 
	IO_processor* processor = this->aritmetico->get_IO_processor();

	delete nombre_archivo_con_extencion;

	// reservamos el espacio para el overhead en el archivo comprimido
	processor->reservar_espacio_para_overhead(this->overhead->get_espacio_reservado());


	bool fin_compresion = false; // bandera para terminar compresion
	while (!fin_compresion)
	{

        this->bloque_caracteres = new UChar[this->t_bloque];

		// leemos de a bloques:	
        if (not_end_of_file(fd)) {

        	//fread devuelve la cantidad que leyo	
        	this->t_bloque = (fread(this->bloque_caracteres,sizeof(UChar),this->t_bloque,fd));
        	cout << "cantidad tomada por bloque: " << this->t_bloque << endl;

        	// lectura adelantada
        	if ( !(not_end_of_file(fd)) ) { // si es fin de archivo, debemos poner en true la bandera
				cout << "estoy en ultimo bloque" << endl;
				fin_compresion = true;
			}

        }
		
		cout << "Block Sorting:" << endl;

		// pedimos memoria again! (ojo) : con super eficiencia podrias pisar??
		UChar* resultadoParcial = new UChar[this->t_bloque];

		// tener comentada o una u otra (!)
		//LInt indiceParcial = blockSortingLeft(resultadoParcial, this->bloque_caracteres, this->t_bloque);
		LInt indiceParcial = blockSorting(resultadoParcial, this->bloque_caracteres, this->t_bloque);
		
		cout << "grabamos el indice: " << indiceParcial << endl;
		this->overhead->guardar_indice(indiceParcial);

		cout << "Move to front:" << endl;

		// creamos "overhead" parcial de modelos -> se podria encapsular en la clase overhead???????????????
		LInt cantidad_de_sub_bloques_aux = (LInt)(this->t_bloque / TAMANIO_SUB_BLOQUE);
		if ( (this->t_bloque % TAMANIO_SUB_BLOQUE) > 0 ) {
			cantidad_de_sub_bloques_aux++;
		}

		Modelos* modelos_predominantes_aux = new Modelos[cantidad_de_sub_bloques_aux];
		//

		resultadoParcial = this->mtf->moveToFront(resultadoParcial,this->t_bloque, modelos_predominantes_aux);


		cout << "modelos predominantes:" << endl;
		for (int i = 0; i < cantidad_de_sub_bloques_aux; i++) {
			cout << (int)modelos_predominantes_aux[i] << "-";

		}
		cout << endl;
		cout << "cantidad de modelos mostrados: " << cantidad_de_sub_bloques_aux << endl;

		
		cout << "Compresion!" << endl;
		int iterador = 0;
		aritmetico->cambiar_modelo(modelos_predominantes_aux[iterador]);
		iterador++;
		for (int i = 0; i < this->t_bloque; i++) {
			if ( (i != 0 ) && (i % TAMANIO_SUB_BLOQUE  == 0) ) {
				aritmetico->cambiar_modelo(modelos_predominantes_aux[iterador]);
				iterador++;
			}
			aritmetico->comprimir_valor(resultadoParcial[i]);
		}
		
		if (fin_compresion) {
			aritmetico->comprimir_valor(eof); // Comprime EOF
			aritmetico->terminarCompresion();
		}


		// grabamos los modelos predominantes -> dump de modelos predominantes parciales a modelos predominantes totales
		for (int i = 0; i < cantidad_de_sub_bloques_aux; i++) {
			this->overhead->guardar_modelo_predominante(modelos_predominantes_aux[i]);
		}

		// banderas
		cout << "cantidad bits comprimidos " << this->aritmetico->get_cantidad_bits_comprimidos() << endl;
		cout << "cantidad bytes comprimidos " << (this->aritmetico->get_cantidad_bits_comprimidos()/8) << endl;
		cout << "cantidad de breaks " << this->aritmetico->get_cantidad_de_breaks() << endl;
		cout << "cantidad de caracteres" << this->t_bloque << endl;

		/** LIBERAR MEMORIA **/
		delete [] this->bloque_caracteres;
		delete [] resultadoParcial;
		delete [] modelos_predominantes_aux;
	
	}

	// escribir overhead indices

	processor->escribir_en_overhead(this->overhead->get_cantidad_de_bloques());
	processor->escribir_en_overhead(this->overhead->get_bloque_de_indices(), this->overhead->get_cantidad_de_bloques());

	// escribir overhead modelos

	processor->escribir_en_overhead(this->overhead->get_cantidad_de_sub_bloques());
	processor->escribir_en_overhead(this->overhead->get_modelos_predominantes_agrupados_por_byte(), this->overhead->get_cantidad_modelos_agrupados_por_byte());

	/** LIBERAR MEMORIA **/
	delete this->overhead;
	
	/** CERRAR ARCHIVO **/
	fclose(fd); //siempre cerrarlo!

}


void Compresor::descomprimir(char* nombre_archivo_con_extencion){

	Nombre_archivo* nombre_archivo = new Nombre_archivo(nombre_archivo_con_extencion);

	if (nombre_archivo->borrar_extencion(".1")) {

		// crear archivo para la descompression
		if (escritor->set_nombre_archivo_nuevo(nombre_archivo->cast_to_ptrchar())) {
			
			cout << "descomprimir y generar archivo salida" << endl; // ir descomprimiendo y guardando 
			
			// notar que se le pasa el archivo con extencion, ya que sobre el mismo queremos descomprimir!
			aritmetico->set_nombre_archivo_descompresion(nombre_archivo_con_extencion); 

			// cargar overhead (hasta aca quede)
			this->overhead = new Overhead(aritmetico->get_IO_processor());


			this->t_bloque = MEMORIA_POR_ACCESO;
			bool fin_descompresion = false;

			aritmetico->empezar_descompresion(); 

			while (!fin_descompresion) {

				this->bloque_caracteres = new UChar[this->t_bloque];

				LInt long_tira = 0;

				LInt indice_actual = this->overhead->get_indice_actual();

				cout << "indice: " << indice_actual << endl;

				Valor caracterDescomprimido;

				while ( (long_tira < MEMORIA_POR_ACCESO) ) {
					

					int iterador = 0;
					aritmetico->cambiar_modelo(this->overhead->get_modelo_predominante_actual());
					while ((long_tira < MEMORIA_POR_ACCESO) && (iterador < TAMANIO_SUB_BLOQUE)) {
						caracterDescomprimido = aritmetico->descomprimir_valor();
						//cout << "caracterDescomprimido: " << (int)caracterDescomprimido << endl;

						if (caracterDescomprimido == eof) {
							cout << "encontro EOF" << endl;
							fin_descompresion =true;
							break;
						}
						this->bloque_caracteres[long_tira] = (UChar)caracterDescomprimido;
						long_tira++;
						//cout << "longtira: " << long_tira << endl;
						iterador++;
					}

					if (caracterDescomprimido == eof) {
						cout << "encontro EOF" << endl;
						fin_descompresion =true;
						break;
					}

				}

				cout << "longitud: "<< long_tira << endl;
				
				cout << "vuelta Move to front:" << endl;

				UChar* resultadoParcial = new UChar[long_tira];
				resultadoParcial = this->mtf->vueltaMoveToFront(this->bloque_caracteres, long_tira);

				cout << "vuelta Block Sorting:" << endl;

				//this->bloque_caracteres = vueltaBlockSortingLeft(resultadoParcial,indice_actual,long_tira);
				this->bloque_caracteres = vueltaBlockSorting(resultadoParcial,indice_actual,long_tira);

				this->escritor->escribir(bloque_caracteres,long_tira);

				delete [] this->bloque_caracteres, resultadoParcial;
				

			}

			this->escritor->cerrar_archivo();
			delete this->overhead;

		} else{
			cout << "error al descomprimir: ya existe el archivo" << endl;
		}

	} else {
		cout << "error al descomprimir: el archivo que desea descomprimir, tiene una extención incorrecta o ni siquiera existe" << endl;
	}

	delete nombre_archivo;

}

// nada que ver jeje
bool Compresor::not_end_of_file(FILE* &fd) {
	if  ( feof(fd) ) {
		return false;
	} else {
		return true;
	}
}



	
	
		/** TESTs **/

		// test bloque 0's:
		/*
		UChar* bloque_test = new UChar[this->t_bloque];

		for ( int i = 0 ; i < this->t_bloque ; i++) {

			bloque_test[i] = 'a';

		}

		bloque_test = moveToFront(bloque_test,this->t_bloque);

		for (LInt i = 0 ; i < this->t_bloque ; i++) {
			cout << (int)bloque_test[i]<<"-";
		}
		cout << endl;

		for (int i = 0; i < this->t_bloque; i++) {
			aritmetico->comprimir_valor(bloque_test[i]);
		}
		if (this->t_bloque < MEMORIA_POR_ACCESO) {
			aritmetico->terminarCompresion();
		}
		*/

	
		// test a mano:
		/*aritmetico->comprimir_valor(38);
		aritmetico->comprimir_valor(12);
		aritmetico->comprimir_valor(0);
	
		aritmetico->terminarCompresion();
		*/