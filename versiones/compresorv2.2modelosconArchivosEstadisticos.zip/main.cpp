
#include <iostream>
#include <unistd.h> // para introducir parametros
#include "Compresor.h"

using namespace std;


int main(int argc, char *argv[]) 
{

	// Parametros para validacion
	int cflag = 0;
 	int dflag = 0;
 	int errflag = 0; // sirve para corregir el caso: -d -c || -c -d
 	int c;
	//

	char* nombreDelArchivo;
     
    // getopt: command-line parser
    while ((c = getopt (argc, argv, "cd")) != -1)
    {
        switch (c)
        {
           case 'c':
            	cflag = 1;
            	if (dflag == 1) {
            		errflag = 1;
            	}
            	break;
           case 'd':
            	dflag = 1; 
            	if (cflag == 1) {
            		errflag = 1;
            	}
            	break; 
           case '?': // parametros invalidos: -fsfs -sdfsd etc.
           		errflag = 1;
           		 	        
        }
    }

    // Validacion de flags
    if ( errflag == 1 ) {

    	cout << "le erraste champion!" << endl;  
    	return 1; 

    } else {

        Compresor* compresor = new Compresor();
        
        // obtenemos el nombre del archivo
        nombreDelArchivo = argv[2];   // argv[2] es la posicion en argv del 3er parametro
        //cout << nombreDelArchivo << endl;

    	if (cflag == 1 ) 
    	{ 
    		cout << "Compresion:" << endl; 
            compresor->comprimir(nombreDelArchivo);
        }
    	
    	if (dflag == 1 ) 
    	{
    		cout << "Descompresion:" << endl; 
            compresor->descomprimir(nombreDelArchivo);

    	};

        delete compresor;
    }

return 0;

}